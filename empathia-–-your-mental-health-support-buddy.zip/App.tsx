
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Chat } from "@google/genai";
import { Message, Author } from './types';
import { createChatSession } from './services/geminiService';
import { ChatBubble } from './components/ChatBubble';
import { MessageInput } from './components/MessageInput';

const App: React.FC = () => {
  const [chat, setChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const initializeChat = () => {
      try {
        const chatSession = createChatSession();
        setChat(chatSession);
        setMessages([
          {
            author: Author.EMPATHIA,
            text: "Hello! I'm Empathia, your supportive buddy. I'm here to listen whenever you're ready to share. How are you feeling today?",
          },
        ]);
        setIsLoading(false);
      } catch (error) {
        console.error("Failed to initialize chat:", error);
        setMessages([
          {
            author: Author.EMPATHIA,
            text: "I'm having a little trouble connecting right now. Please check if an API key is configured and refresh the page.",
          },
        ]);
      }
    };
    initializeChat();
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (userInput: string) => {
    if (!chat) return;

    setIsLoading(true);
    const userMessage: Message = { author: Author.USER, text: userInput };
    // Add user message and a placeholder for Empathia's response
    setMessages(prevMessages => [
        ...prevMessages, 
        userMessage,
        { author: Author.EMPATHIA, text: '...' }
    ]);
    
    try {
      const stream = await chat.sendMessageStream({ message: userInput });

      let responseText = '';
      for await (const chunk of stream) {
        responseText += chunk.text;
        setMessages(prev => {
            const newMessages = [...prev];
            // Update the last message (Empathia's placeholder)
            newMessages[newMessages.length - 1] = { ...newMessages[newMessages.length - 1], text: responseText + '▌' };
            return newMessages;
        });
      }
      // Final update without the cursor
      setMessages(prev => {
        const newMessages = [...prev];
        newMessages[newMessages.length - 1] = { ...newMessages[newMessages.length - 1], text: responseText };
        return newMessages;
      });

    } catch (error) {
      console.error('Error sending message:', error);
      setMessages(prev => {
        const newMessages = [...prev];
        newMessages[newMessages.length - 1] = { author: Author.EMPATHIA, text: "I'm sorry, I encountered an error. Could you please try again?" };
        return newMessages;
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-100">
      <header className="bg-white shadow-sm p-4 border-b border-gray-200">
        <div className="max-w-4xl mx-auto flex items-center">
            <div className="w-12 h-12 rounded-full bg-teal-100 flex items-center justify-center mr-4">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-teal-600" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10 3.5a1.5 1.5 0 013 0V4a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-.5a1.5 1.5 0 000 3h.5a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-.5a1.5 1.5 0 00-3 0v.5a1 1 0 01-1 1H6a1 1 0 01-1-1v-3a1 1 0 011-1h.5a1.5 1.5 0 000-3H6a1 1 0 01-1-1V6a1 1 0 011-1h3a1 1 0 001-1v-.5z" />
                </svg>
            </div>
            <div>
                 <h1 className="text-xl font-bold text-gray-800">Empathia</h1>
                 <p className="text-sm text-gray-500">Your Mental Health Support Buddy</p>
            </div>
        </div>
      </header>
      <main className="flex-grow p-4 overflow-y-auto">
        <div className="max-w-4xl mx-auto">
          {messages.map((msg, index) => (
            <ChatBubble key={index} message={msg} />
          ))}
          <div ref={messagesEndRef} />
        </div>
      </main>
      <footer className="max-w-4xl mx-auto w-full">
        <MessageInput onSendMessage={handleSendMessage} isLoading={isLoading} />
      </footer>
    </div>
  );
};

export default App;
