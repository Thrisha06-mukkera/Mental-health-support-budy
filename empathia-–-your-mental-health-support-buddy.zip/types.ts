
export enum Author {
  USER = 'user',
  EMPATHIA = 'empathia',
}

export interface Message {
  author: Author;
  text: string;
}
