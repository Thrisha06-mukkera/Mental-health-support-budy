
import React from 'react';
import { Author, Message } from '../types';

interface ChatBubbleProps {
  message: Message;
}

const EmpathiaIcon = () => (
  <div className="w-10 h-10 rounded-full bg-teal-200 flex items-center justify-center flex-shrink-0 mr-3">
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-teal-700" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
    </svg>
  </div>
);

const UserIcon = () => (
  <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center flex-shrink-0 ml-3">
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
    </svg>
  </div>
);

export const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isUser = message.author === Author.USER;

  return (
    <div className={`flex items-start my-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
      {!isUser && <EmpathiaIcon />}
      <div
        className={`px-5 py-3 rounded-2xl max-w-lg shadow-sm ${
          isUser
            ? 'bg-blue-500 text-white rounded-br-none'
            : 'bg-white text-gray-800 rounded-bl-none'
        }`}
      >
        <p className="whitespace-pre-wrap">{message.text}</p>
      </div>
      {isUser && <UserIcon />}
    </div>
  );
};
